Current Line Text Color - Notepad++ plugin
==========================================
Colours the TEXT on the line the caret is on (Notepad++ themes can only colour the background).
When the caret moves, the old line goes back to its normal theme colours automatically.

INSTALL
1. Check which Notepad++ you have: ? > About Notepad++ (64-bit or 32-bit).
2. Copy the folder "CurrentLineTextColor" from x64\ (64-bit) or x86\ (32-bit) into
   C:\Program Files\Notepad++\plugins\        (portable install: <npp folder>\plugins\)
   Result: ...\plugins\CurrentLineTextColor\CurrentLineTextColor.dll
   (Administrator rights are needed for Program Files.)
3. Restart Notepad++. A new entry appears under Plugins > Current Line Text Color.

SETTINGS  (Plugins > Current Line Text Color > Open settings file)
   %APPDATA%\Notepad++\plugins\Config\CurrentLineTextColor.ini

   [Settings]
   Enabled=1              1 = on, 0 = off
   TextColor=F8F8FD       text colour of the current line (RRGGBB)
   LineBackground=7F7AA8  background of the current line (RRGGBB); leave empty to keep your theme's
                          "Current line background colour"

After editing: Plugins > Current Line Text Color > Reload settings.

NOTES
- The whole current line gets one text colour (syntax colours are overridden on that line only).
- Needs Settings > Preferences > Editing > "Enable current line highlighting".
- ARM64 Notepad++ builds are not included.
