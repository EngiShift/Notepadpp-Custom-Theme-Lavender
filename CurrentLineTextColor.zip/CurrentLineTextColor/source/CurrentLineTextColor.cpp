// CurrentLineTextColor - Notepad++ plugin
// Colours the TEXT of the caret line (Notepad++ itself only lets themes colour its background).
// Technique: a Scintilla INDIC_TEXTFORE indicator is painted over the caret line on every
// selection / content change and removed from the previous line automatically.
#include <windows.h>
#include <cstdlib>
#include <cwchar>
#include "PluginInterface.h"

static const wchar_t* PLUGIN_NAME = L"Current Line Text Color";
static const int      INDIC       = 10;   // indicator slot (not used by Notepad++ itself)

static NppData g_npp;
static bool    g_enabled   = true;
static COLORREF g_textColor = RGB(0xF8, 0xF8, 0xFD);
static bool    g_setBack   = true;
static COLORREF g_backColor = RGB(0x7F, 0x7A, 0xA8);
static wchar_t g_ini[MAX_PATH] = L"";

static void toggleEnabled();
static void reloadSettings();
static void openSettings();

static FuncItem g_funcs[3];

static COLORREF parseHex(const wchar_t* s, COLORREF def, bool* ok = nullptr)
{
    if (ok) *ok = false;
    while (*s == L' ' || *s == L'#') ++s;
    if (wcslen(s) < 6) return def;
    wchar_t buf[7]; wcsncpy(buf, s, 6); buf[6] = 0;
    wchar_t* end = nullptr;
    unsigned long v = wcstoul(buf, &end, 16);
    if (*end) return def;
    if (ok) *ok = true;
    return RGB((v >> 16) & 0xFF, (v >> 8) & 0xFF, v & 0xFF);
}

static void writeDefaults()
{
    if (GetFileAttributesW(g_ini) != INVALID_FILE_ATTRIBUTES) return;
    WritePrivateProfileStringW(L"Settings", L"Enabled", L"1", g_ini);
    WritePrivateProfileStringW(L"Settings", L"TextColor", L"F8F8FD", g_ini);
    WritePrivateProfileStringW(L"Settings", L"LineBackground", L"7F7AA8", g_ini);
}

static void loadSettings()
{
    wchar_t buf[64];
    g_enabled = GetPrivateProfileIntW(L"Settings", L"Enabled", 1, g_ini) != 0;
    GetPrivateProfileStringW(L"Settings", L"TextColor", L"F8F8FD", buf, 64, g_ini);
    g_textColor = parseHex(buf, RGB(0xF8, 0xF8, 0xFD));
    GetPrivateProfileStringW(L"Settings", L"LineBackground", L"", buf, 64, g_ini);
    bool ok = false;
    g_backColor = parseHex(buf, RGB(0x7F, 0x7A, 0xA8), &ok);
    g_setBack = ok;   // empty / invalid value = leave the theme's current-line colour alone
}

static LRESULT sci(HWND h, UINT m, WPARAM w = 0, LPARAM l = 0) { return SendMessage(h, m, w, l); }

static void clearView(HWND h)
{
    sci(h, SCI_SETINDICATORCURRENT, INDIC);
    sci(h, SCI_INDICATORCLEARRANGE, 0, sci(h, SCI_GETLENGTH));
}

static void applyView(HWND h)
{
    if (!h) return;
    clearView(h);
    if (!g_enabled) return;
    sci(h, SCI_SETINDICATORCURRENT, INDIC);
    LRESULT pos   = sci(h, SCI_GETCURRENTPOS);
    LRESULT line  = sci(h, SCI_LINEFROMPOSITION, pos);
    LRESULT start = sci(h, SCI_POSITIONFROMLINE, line);
    LRESULT end   = sci(h, SCI_GETLINEENDPOSITION, line);
    if (end > start) sci(h, SCI_INDICATORFILLRANGE, start, end - start);
}

static void setupView(HWND h)
{
    if (!h) return;
    sci(h, SCI_INDICSETSTYLE, INDIC, INDIC_TEXTFORE);
    sci(h, SCI_INDICSETFORE,  INDIC, g_textColor);
    sci(h, SCI_INDICSETALPHA, INDIC, 255);
    sci(h, SCI_INDICSETUNDER, INDIC, 0);
    if (g_enabled && g_setBack) sci(h, SCI_SETCARETLINEBACK, g_backColor);
}

static HWND curView()
{
    int which = -1;
    SendMessage(g_npp._nppHandle, NPPM_GETCURRENTSCINTILLA, 0, (LPARAM)&which);
    return which == 1 ? g_npp._scintillaSecondHandle : g_npp._scintillaMainHandle;
}

static void refreshAll()
{
    setupView(g_npp._scintillaMainHandle);
    setupView(g_npp._scintillaSecondHandle);
    applyView(g_npp._scintillaMainHandle);
    applyView(g_npp._scintillaSecondHandle);
}

static void toggleEnabled()
{
    g_enabled = !g_enabled;
    WritePrivateProfileStringW(L"Settings", L"Enabled", g_enabled ? L"1" : L"0", g_ini);
    SendMessage(g_npp._nppHandle, NPPM_SETMENUITEMCHECK, g_funcs[0]._cmdID, g_enabled);
    refreshAll();
}

static void reloadSettings()
{
    loadSettings();
    SendMessage(g_npp._nppHandle, NPPM_SETMENUITEMCHECK, g_funcs[0]._cmdID, g_enabled);
    refreshAll();
}

static void openSettings()
{
    SendMessage(g_npp._nppHandle, NPPM_DOOPEN, 0, (LPARAM)g_ini);
}

extern "C" {

__declspec(dllexport) void setInfo(NppData data)
{
    g_npp = data;
    wchar_t dir[MAX_PATH] = L"";
    SendMessage(g_npp._nppHandle, NPPM_GETPLUGINSCONFIGDIR, MAX_PATH, (LPARAM)dir);
    CreateDirectoryW(dir, nullptr);
    swprintf(g_ini, MAX_PATH, L"%ls\\CurrentLineTextColor.ini", dir);
    writeDefaults();
    loadSettings();

    wcscpy(g_funcs[0]._itemName, L"Enabled");
    g_funcs[0]._pFunc = toggleEnabled; g_funcs[0]._init2Check = g_enabled; g_funcs[0]._pShKey = nullptr;
    wcscpy(g_funcs[1]._itemName, L"Reload settings");
    g_funcs[1]._pFunc = reloadSettings; g_funcs[1]._init2Check = false; g_funcs[1]._pShKey = nullptr;
    wcscpy(g_funcs[2]._itemName, L"Open settings file");
    g_funcs[2]._pFunc = openSettings; g_funcs[2]._init2Check = false; g_funcs[2]._pShKey = nullptr;
}

__declspec(dllexport) const wchar_t* getName() { return PLUGIN_NAME; }

__declspec(dllexport) FuncItem* getFuncsArray(int* n) { *n = 3; return g_funcs; }

__declspec(dllexport) void beNotified(SCNotification* n)
{
    switch (n->nmhdr.code)
    {
    case NPPN_READY:
    case NPPN_BUFFERACTIVATED:
    case NPPN_WORDSTYLESUPDATED:     // theme / Style Configurator changed: re-apply
        refreshAll();
        break;
    case NPPN_SHUTDOWN:
        break;
    case SCN_UPDATEUI:
        if (n->updated & (SC_UPDATE_SELECTION | SC_UPDATE_CONTENT))
        {
            HWND h = (HWND)n->nmhdr.hwndFrom;
            if (h == g_npp._scintillaMainHandle || h == g_npp._scintillaSecondHandle)
                applyView(h);
        }
        break;
    }
}

__declspec(dllexport) LRESULT messageProc(UINT, WPARAM, LPARAM) { return TRUE; }

__declspec(dllexport) BOOL isUnicode() { return TRUE; }

}

BOOL APIENTRY DllMain(HINSTANCE, DWORD, LPVOID) { return TRUE; }
